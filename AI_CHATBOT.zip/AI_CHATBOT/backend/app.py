from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from models.schemas import RegisterRequest, LoginRequest

from servises.auth_service import (
    register_user,
    login_user
)


from database import SessionLocal
from models.chat import Chat
from models.message import Message

from models.schemas import ChatRequest
from servises.geminiai import get_ai_response

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.post("/new-chat")
def new_chat():

    db = SessionLocal()

    chat = Chat(
        title="New Chat"
    )

    db.add(chat)

    db.commit()

    db.refresh(chat)

    db.close()

    return {
        "chat_id": chat.id
    }


@app.get("/chats")
def get_chats():

    db = SessionLocal()

    chats = (
        db.query(Chat)
        .order_by(Chat.id.desc())
        .all()
    )

    result = []

    for chat in chats:

        result.append({

            "id": chat.id,

            "title": chat.title

        })

    db.close()

    return result

@app.get("/chat/{chat_id}")
def get_chat(chat_id: int):

    db = SessionLocal()

    messages = (
        db.query(Message)
        .filter(Message.chat_id == chat_id)
        .order_by(Message.id)
        .all()
    )

    result = []

    for msg in messages:

        result.append({

            "role": msg.role,

            "message": msg.message

        })

    db.close()

    return result

@app.delete("/chat/{chat_id}")
def delete_chat(chat_id: int):

    db = SessionLocal()

    chat = db.query(Chat).filter(Chat.id == chat_id).first()

    if chat is None:

        db.close()

        return {"message": "Chat not found"}

    db.delete(chat)

    db.commit()

    db.close()

    return {

        "message": "Chat deleted successfully"

    }

@app.post("/register")
def register(request: RegisterRequest):

    user = register_user(
        request.email,
        request.password
    )

    if user is None:

        return {
            "success": False,
            "message": "Email already registered"
        }

    return {
        "success": True,
        "message": "User registered successfully",
        "user_id": user.id
    }

@app.post("/login")
def login(request: LoginRequest):

    token = login_user(
        request.email,
        request.password
    )

    if token is None:

        return {
            "success": False,
            "message": "Invalid email or password"
        }

    return {
        "success": True,
        "message": "Login successful",
        "token": token
    }



@app.post("/chat")
def chat(request: ChatRequest):

    reply = get_ai_response(
        chat_id=request.chat_id,
        message=request.message
    )

    return {

    
        "response": reply
    }
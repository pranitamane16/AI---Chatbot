import bcrypt
import jwt

from database import SessionLocal
from models.user import User


SECRET_KEY = "change-this-secret-key"

ALGORITHM = "HS256"


def hash_password(password: str):

    hashed = bcrypt.hashpw(
        password.encode("utf-8"),
        bcrypt.gensalt()
    )

    return hashed.decode("utf-8")


def verify_password(password: str, hashed_password: str):

    return bcrypt.checkpw(
        password.encode("utf-8"),
        hashed_password.encode("utf-8")
    )


def create_token(user_id: int):

    payload = {
        "user_id": user_id
    }

    token = jwt.encode(
        payload,
        SECRET_KEY,
        algorithm=ALGORITHM
    )

    return token


def register_user(email: str, password: str):

    db = SessionLocal()

    existing_user = (
        db.query(User)
        .filter(User.email == email)
        .first()
    )

    if existing_user:

        db.close()

        return None

    hashed_password = hash_password(password)

    user = User(
        email=email,
        password=hashed_password
    )

    db.add(user)

    db.commit()

    db.refresh(user)

    db.close()

    return user


def login_user(email: str, password: str):

    db = SessionLocal()

    user = (
        db.query(User)
        .filter(User.email == email)
        .first()
    )

    if user is None:

        db.close()

        return None

    if not verify_password(password, user.password):

        db.close()

        return None

    token = create_token(user.id)

    db.close()

    return token
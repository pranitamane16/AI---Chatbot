from database import SessionLocal
from models.chat import Chat


def update_chat_title(chat_id: int, message: str):

    db = SessionLocal()

    chat = db.query(Chat).filter(Chat.id == chat_id).first()

    if chat is None:
        db.close()
        return

    # Update title only if it's still "New Chat"
    if chat.title == "New Chat":

        title = message.strip()

        if len(title) > 40:
            title = title[:40] + "..."

        chat.title = title

        db.commit()

    db.close()
from google import genai

from config import GEMINI_API_KEY

from database import SessionLocal

from models.message import Message
from servises.chat_servises import update_chat_title

client = genai.Client(api_key=GEMINI_API_KEY)


def get_ai_response(chat_id: int, message: str):

    update_chat_title(chat_id, message)

    db = SessionLocal()

    # Save user message
    db.add(
        Message(
            chat_id=chat_id,
            role="user",
            message=message
        )
    )

    db.commit()

    # Read chat history
    messages = (
        db.query(Message)
        .filter(Message.chat_id == chat_id)
        .order_by(Message.id)
        .all()
    )

    history = []

    for msg in messages:

        history.append(
            f"{msg.role}: {msg.message}"
        )

    prompt = "\n".join(history)

    prompt += "\nassistant:"

    response = client.models.generate_content(

        model="gemini-3.5-flash-lite",

        contents=prompt

    )

    ai_reply = response.text

    # Save AI response
    db.add(
        Message(
            chat_id=chat_id,
            role="assistant",
            message=ai_reply
        )
    )

    db.commit()

    db.close()

    return ai_reply
from sqlalchemy import Column, Integer, String, Text, DateTime, ForeignKey
from sqlalchemy.sql import func

from database import Base


class Message(Base):

    __tablename__ = "messages"

    id = Column(Integer, primary_key=True, index=True)

    chat_id = Column(Integer, ForeignKey("chats.id", ondelete="CASCADE"))

    role = Column(String(20))

    message = Column(Text)

    created_at = Column(DateTime(timezone=True), server_default=func.now())
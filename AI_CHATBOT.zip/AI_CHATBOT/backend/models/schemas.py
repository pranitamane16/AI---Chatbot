from pydantic import BaseModel


class ChatRequest(BaseModel):

    chat_id: int
    message: str


class ChatResponse(BaseModel):

    response: str


class NewChatResponse(BaseModel):

    chat_id: int


class RegisterRequest(BaseModel):

    email: str
    password: str


class LoginRequest(BaseModel):

    email: str
    password: str
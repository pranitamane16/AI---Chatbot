const registerForm =
    document.getElementById("register-form");

const errorMessage =
    document.getElementById("error-message");


registerForm.addEventListener(
    "submit",
    async function (event) {

        event.preventDefault();

        const email =
            document.getElementById("email").value.trim();

        const password =
            document.getElementById("password").value;

        const confirmPassword =
            document.getElementById("confirm-password").value;


        errorMessage.textContent = "";


        if (password !== confirmPassword) {

            errorMessage.textContent =
                "Passwords do not match.";

            return;
        }


        try {

            const response = await fetch(
                "http://127.0.0.1:8000/register",
                {

                    method: "POST",

                    headers: {
                        "Content-Type": "application/json"
                    },

                    body: JSON.stringify({
                        email: email,
                        password: password
                    })

                }
            );


            const data = await response.json();


            if (data.success) {

                alert(
                    "Account created successfully!"
                );

                window.location.href =
                    "login.html";

            } else {

                errorMessage.textContent =
                    data.message;

            }

        } catch (error) {

            console.error(error);

            errorMessage.textContent =
                "Unable to connect to server.";

        }

    }
);
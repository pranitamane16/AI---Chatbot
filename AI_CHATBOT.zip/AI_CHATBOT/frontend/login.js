const loginForm = document.getElementById("login-form");
const errorMessage = document.getElementById("error-message");

loginForm.addEventListener("submit", async function (event) {

    event.preventDefault();

    const email = document.getElementById("email").value.trim();
    const password = document.getElementById("password").value;

    errorMessage.textContent = "";

    if (email === "" || password === "") {

        errorMessage.textContent =
            "Please enter email and password.";

        return;
    }

    try {

        const response = await fetch(
            "http://127.0.0.1:8000/login",
            {
                method: "POST",

                headers: {
                    "Content-Type": "application/json"
                },

                body: JSON.stringify({
                    email: email,
                    password: password
                })
            }
        );

        const data = await response.json();

        if (data.success) {

            // Save JWT token
            localStorage.setItem("token", data.token);

            // Save user email
            localStorage.setItem("user_email", email);

            // Open chatbot
            window.location.href = "index.html";

        } else {

            errorMessage.textContent =
                data.message || "Invalid email or password.";

        }

    } catch (error) {

        console.error(error);

        errorMessage.textContent =
            "Unable to connect to server.";

    }

});
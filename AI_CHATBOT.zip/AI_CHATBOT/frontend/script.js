const chatBox = document.getElementById("chat-box");
const input = document.getElementById("user-input");
const sendBtn = document.getElementById("send-btn");
const newChatBtn = document.querySelector(".new-chat");
const historyDiv = document.getElementById("history");
let currentChatId = null;

// ----------------------
// Send Message
// ----------------------

function sendMessage() {

    const message = input.value.trim();

    if (message === "") return;

    addMessage(message, "user");

    input.value = "";
    input.style.height = "auto";

    getBotResponse(message);

}

// ----------------------
// Add Message
// ----------------------

function addMessage(text, sender) {

    const div = document.createElement("div");

    div.classList.add("message", sender);

    if (sender === "bot") {

        div.innerHTML = marked.parse(text);

        div.querySelectorAll("pre code").forEach((block) => {
            hljs.highlightElement(block);
        });

    } else {

        div.textContent = text;

    }

    chatBox.appendChild(div);

    scrollToBottom();

}

// ----------------------
// Gemini Response
// ----------------------

async function getBotResponse(message) {

    const thinking = document.createElement("div");

    thinking.classList.add("message", "bot");

    thinking.textContent = "Thinking...";

    chatBox.appendChild(thinking);

    scrollToBottom();

    try {

        const response = await fetch("http://127.0.0.1:8000/chat", {

            method: "POST",

            headers: {
                "Content-Type": "application/json"
            },

            body: JSON.stringify({
                chat_id: currentChatId,
                message: message
            })

        });

        const data = await response.json();

        thinking.innerHTML = marked.parse(data.response);

        thinking.querySelectorAll("pre code").forEach((block) => {
            hljs.highlightElement(block);
        });

    } catch (error) {

        thinking.textContent = "Server Error";

        console.error(error);

    }

    scrollToBottom();

}

// ----------------------
// Scroll
// ----------------------

function scrollToBottom() {

    chatBox.scrollTop = chatBox.scrollHeight;

}

// ----------------------
// New Chat
// ----------------------

async function newChat() {

    try {

        const response = await fetch("http://127.0.0.1:8000/new-chat", {

            method: "POST"

        });

        const data = await response.json();

        currentChatId = data.chat_id;

        chatBox.innerHTML = "";

        addMessage("Hello 👋\n\nHow can I help you today?", "bot");

        input.value = "";

        input.focus();

        console.log("Current Chat:", currentChatId);

    }

    catch(error){

        console.log(error);

    }

}

// ----------------------
// Auto Resize
// ----------------------

input.addEventListener("input", () => {

    input.style.height = "auto";

    input.style.height = input.scrollHeight + "px";

});

async function loadChats() {

    const response = await fetch("http://127.0.0.1:8000/chats");

    const chats = await response.json();

    historyDiv.innerHTML = "";

    chats.forEach(chat => {

        const div = document.createElement("div");

div.className = "chat-item";

const title = document.createElement("span");

title.innerText = chat.title;

title.onclick = () => loadChat(chat.id);

const deleteBtn = document.createElement("button");

deleteBtn.innerHTML = "🗑";

deleteBtn.className = "delete-btn";

deleteBtn.onclick = async (e) => {

    e.stopPropagation();

    if (!confirm("Delete this chat?"))
        return;

    await fetch(`http://127.0.0.1:8000/chat/${chat.id}`,{

        method:"DELETE"

    });

    loadChats();

    if(currentChatId === chat.id){

        chatBox.innerHTML = "";

        newChat();

    }

};

div.appendChild(title);

div.appendChild(deleteBtn);

historyDiv.appendChild(div);

    });

}

async function loadChat(chatId) {

    currentChatId = chatId;

    const response = await fetch(

        `http://127.0.0.1:8000/chat/${chatId}`

    );

    const messages = await response.json();

    chatBox.innerHTML = "";

    messages.forEach(msg => {

        addMessage(

            msg.message,

            msg.role === "assistant" ? "bot" : "user"

        );

    });

}

// ----------------------
// Enter Key
// ----------------------

input.addEventListener("keydown", function (event) {

    if (event.key === "Enter" && !event.shiftKey) {

        event.preventDefault();

        sendMessage();

    }

});

// ----------------------
// Buttons
// ----------------------

sendBtn.addEventListener("click", sendMessage);



newChatBtn.addEventListener("click", newChat);

newChat();
loadChats();